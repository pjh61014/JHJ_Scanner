# -*- coding: utf-8 -*-
'''
Created on 2016. 7. 26.

@author: JongHyuk
'''

def report(pattern, count):
    print "x"
